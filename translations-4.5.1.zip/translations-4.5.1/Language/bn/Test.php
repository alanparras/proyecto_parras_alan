<?php

/**
 * This file is part of CodeIgniter 4 framework.
 *
 * (c) CodeIgniter Foundation <admin@codeigniter.com>
 *
 * For the full copyright and license information, please view
 * the LICENSE file that was distributed with this source code.
 */

// Testing language settings
return [
    'invalidMockClass' => '{0} একটি বৈধ মক ক্লাস নয়',
];
