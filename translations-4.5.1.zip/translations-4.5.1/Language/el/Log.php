<?php

/**
 * This file is part of CodeIgniter 4 framework.
 *
 * (c) CodeIgniter Foundation <admin@codeigniter.com>
 *
 * For the full copyright and license information, please view
 * the LICENSE file that was distributed with this source code.
 */

// Log language settings
return [
    'invalidLogLevel'    => '"{0}" μη έγκυρο επίπεδο καταγραφής.', // '"{0}" is an invalid log level.',
    'invalidMessageType' => 'Ο δεδομένος τύπος μηνύματος "{0}" δεν υποστηρίζεται.', // 'The given message type "{0}" is not supported.',
];
